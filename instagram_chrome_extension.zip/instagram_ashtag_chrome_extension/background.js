chrome.runtime.onInstalled.addListener(() => {
    console.log("Tiktok Scraper Extension Installed");
  });